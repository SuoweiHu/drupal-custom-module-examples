<?php

/**
 * @file
 * Contains \Drupal\leasing\Form\RegistrationForm.
 */

namespace Drupal\leasing\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\ReplaceCommand;


class LeasingForm extends FormBase
{

    /**
     * Retrieves the authentication token from the API.
     *
     * @return string The access token.
     */
    function getAccessToken()
    {
        // Get the authentication token from the API
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.staging.catch-e.com/authenticate',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('username' => 'suowei_h', 'password' => 't!7M$xY2e9qR', 'token_timeout' => '28800'),
            CURLOPT_HTTPHEADER => array('Client-Id: payme'),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        // Decode JSON response to get the authentication token
        $arrayData     = json_decode($response, true);
        $access_token  = $arrayData["access_token"];
        $expires_in    = $arrayData["expires_in"];
        $token_type    = $arrayData["token_type"];
        return $access_token;
    }
    /**
     * Retrieves a list of vehicle makes from the API.
     *
     * @param string $access_token The access token required to authenticate the request.
     * @return array An associative array of make IDs and translated names.
     */
    function getMakes($access_token)
    {
        // Get the options from the API (note that you will have to have "Authorization: Bearer your-auth-code-here" header to make the request)
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL             => 'https://api.staging.catch-e.com/web-services/qq/vehicle_lookup/getMakes',
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_ENCODING        => '',
            CURLOPT_MAXREDIRS       => 10,
            CURLOPT_TIMEOUT         => 0,
            CURLOPT_FOLLOWLOCATION  => true,
            CURLOPT_HTTP_VERSION    => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST   => 'GET',
            CURLOPT_HTTPHEADER      => array('Authorization: Bearer ' . $access_token),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        // Decode JSON response into drupal format of multiple selection options
        $arrayData = json_decode($response, true);
        $resultArray = array();
        $resultArray["NA"] = "-------------------N/A-------------------";
        foreach ($arrayData["makes"] as $row) {
            $makeId = $row['make_id'];
            $name = $row['name'];
            $resultArray[$makeId] = t($name);
        }
        return $resultArray;
    }


    /**
     * Retrieves a list of vehicle models from the API.
     *
     * @param string $make_id The make id of the vehicle
     * @param string $access_token The access token required to authenticate the request.
     * @return array An associative array of make IDs and translated names.
     */
    // function getModels($access_token, $make_id)
    function getModels($make_id)
    {
        // Handling edge case
        if ($make_id=="NA" or $make_id==""){
            $empty = ["NA"=>t("-------------------N/A-------------------")];
            return $empty;
        }
        /// Get the options from the API
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://payme.catch-e.net.au/services/qq/vehicle_lookup/getModels?profile_required=yes&login=web_alliance&password=caRZT70Gv8pHs&make_id=' . $make_id,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        // Decode JSON response into drupal format of multiple selection options
        $xml = simplexml_load_string($response);
        $resultArray = array();
        $resultArray["NA"] = "-------------------N/A-------------------";
        foreach ($xml->models->children() as $row) {
            $modelId = (string) $row->model_id;
            $name = (string) $row->name;
            $resultArray[$modelId] = $name;
        }
        return $resultArray;
    }


    function getModelYears($model_id)
    {
        // Handling edge case
        if ($model_id=="NA" or $model_id==""){
            return ["NA"=>t("-------------------N/A-------------------")];
        }
        // Get the options from the API
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://payme.catch-e.net.au/services/qq/vehicle_lookup/getModelYears/?login=web_alliance&password=caRZT70Gv8pHs&model_id=' . $model_id,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        // Decode JSON response into drupal format of multiple selection options
        $xml = simplexml_load_string($response);
        $resultArray = array();
        $resultArray["NA"] = "-------------------N/A-------------------";
        foreach ($xml->model_years->children() as $row) {
            $modelId = (string) $row->model_year;
            $name = (string) $row->model_year;
            $resultArray[$modelId] = $name;
        }
        return $resultArray;
    }

    function getModelBodyTypeIDs($model_id, $model_year){
        // Handling edge case
        if ($model_id=="NA" or $model_year=="NA" or $model_id=="" or $model_year==""){
            return ["NA"=>t("-------------------N/A-------------------")];
        }
        // Get the options from the API
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://payme.catch-e.net.au/services/qq/vehicle_lookup/getBodyTypes/?login=web_alliance&password=caRZT70Gv8pHs&model_id=".$model_id."&model_year=".$model_year,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(),
        ));
        $response = curl_exec($curl);
        curl_close($curl);

        // Decode JSON response into drupal format of multiple selection options
        $xml = simplexml_load_string($response);
        $resultArray = array();
        $resultArray["NA"] = "-------------------N/A-------------------";
        foreach ($xml->body_types->children() as $row) {
            $modelId = (string) $row->body_type_id;
            $name = (string) $row->body_type;
            $resultArray[$modelId] = $name;
        }
        return $resultArray;
    }
    function getVariants($model_id, $model_year, $body_type){
        // Handling edge case
        if ($model_id=="NA" or $model_year=="NA" or $body_type=="NA" or $model_id=="" or $model_year=="" or $body_type==""){
            return ["NA"=>t("-------------------N/A-------------------")];
        }
        // Get the options from the API
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://payme.catch-e.net.au/services/qq/vehicle_lookup/getVariants/?login=web_alliance&password=caRZT70Gv8pHs&model_id=".$model_id."&model_year=".$model_year."&body_type_id=".$body_type,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(),
        ));
        $response = curl_exec($curl);
        curl_close($curl);

        // Decode JSON response into drupal format of multiple selection options
        $xml = simplexml_load_string($response);
        $resultArray = array();
        $resultArray["NA"] = "-------------------N/A-------------------";
        foreach ($xml->variants->children() as $row) {
            $modelId = (string) $row->variant_id;
            $name = (string) $row->description;
            $resultArray[$modelId] = $name;
        }
        return $resultArray;
    }

    function getCarPrice($variant_id){
        // Get the options from the API
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://payme.catch-e.net.au/services/qq/vehicle_lookup/getVariant/?login=web_alliance&password=caRZT70Gv8pHs&variant_id=".$variant_id,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(),
        ));
        $response = curl_exec($curl);
        curl_close($curl);

        // Decode JSON response into drupal format of multiple selection options
        $xml = simplexml_load_string($response);
        return (string) $xml -> variant -> list_price_gross;
    }

    function getCarImageHTML($variant_id){
        // Get the options from the API
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://payme.catch-e.net.au/services/qq/vehicle_lookup/getVariantPhotos/?login=web_alliance&password=caRZT70Gv8pHs&variant_id=".$variant_id,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(),
        ));
        $response = curl_exec($curl);
        curl_close($curl);

        // Decode JSON response into drupal format
        $xml = simplexml_load_string($response);
        $img_code = $xml-> variant -> photo_code;
        $html_image = "<img src=\"https://payme2.catch-e.net.au/core/services/Redbook/photos/AUS/$img_code.jpg\"/>";
        return $html_image;
    }

    function getQuote($variant_id, $approximate_price, $annual_salary, $pay_cycle_code, $annual_kilometres, $state_registered, $lease_period){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://payme.catch-e.net.au/services/qq/lease/getQuote/?login=web_alliance&password=caRZT70Gv8pHs&variant_id=$variant_id&approximate_price=$approximate_price&annual_salary=$annual_salary&pay_cycle_code=$pay_cycle_code&annual_kilometres=$annual_kilometres&state_registered=$state_registered&lease_period=$lease_period",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(),
        ));
        $response = curl_exec($curl);
        curl_close($curl);

        // Decode JSON response into drupal format
        $xml = simplexml_load_string($response);
        $resultArray = array();
        $resultArray['total_lease_per_pay_cycle_gross']             = (string) $xml -> quote -> total_lease_per_pay_cycle_gross;
        $resultArray['packaged_reduction_net_income_per_pay_cycle'] = (string) $xml -> quote -> packaged_reduction_net_income_per_pay_cycle;
        $resultArray['packaged_advantage_per_year']                 = (string) $xml -> quote -> packaged_advantage_per_year;
        $resultArray['fin_per_pay_cycle_net']                       = (string) $xml -> quote -> fin_per_pay_cycle_net;
        $resultArray['maint_per_pay_cycle_net']                     = (string) $xml -> quote -> maint_per_pay_cycle_net;
        $resultArray['t_per_pay_cycle_net']                         = (string) $xml -> quote -> t_per_pay_cycle_net;
        $resultArray['reg_per_pay_cycle_net']                       = (string) $xml -> quote -> reg_per_pay_cycle_net;
        $resultArray['ins_per_pay_cycle_net']                       = (string) $xml -> quote -> ins_per_pay_cycle_net;
        $resultArray['f_per_pay_cycle_net']                         = (string) $xml -> quote -> f_per_pay_cycle_net;
        $resultArray['rsa_per_pay_cycle_net']                       = (string) $xml -> quote -> rsa_per_pay_cycle_net;
        $resultArray['mfee_per_pay_cycle_net']                      = (string) $xml -> quote -> mfee_per_pay_cycle_net;
        $resultArray['total_lease_per_pay_cycle_net']               = (string) $xml -> quote -> total_lease_per_pay_cycle_net;
        $resultArray['total_lease_per_pay_cycle_gst']               = (string) $xml -> quote -> total_lease_per_pay_cycle_gst;
        $resultArray['total_lease_per_pay_cycle_gross']             = (string) $xml -> quote -> total_lease_per_pay_cycle_gross;
        return $resultArray;
    }



    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================


    public function getModels_AjaxCallback(array &$form, FormStateInterface $form_state){
        $options = $this -> getModels($form_state->getValue('make_id'));
        $form['step_1']['model_id']['#options']  =  $options;
        $form['step_1']['model_id']['#value']    = "NA";
        $form['step_1']['model_year']['#value']  = "NA";  $form['step_1']['model_year']['#options']  = ["NA"=>t("-------------------N/A-------------------")];
        $form['step_1']['body_type']['#value']   = "NA";  $form['step_1']['body_type']['#options']   = ["NA"=>t("-------------------N/A-------------------")];
        $form['step_1']['variant']['#value']     = "NA";  $form['step_1']['variant']['#options']     = ["NA"=>t("-------------------N/A-------------------")];
        return $form['step_1']; // return $form["model_id"];
    }

    public function getModelYear_AjaxCallback(array &$form, FormStateInterface $form_state){
        $options = $this -> getModelYears($form_state->getValue('model_id'));
        $form['step_1']['model_year']['#options'] = $options;
        $form['step_1']['model_year']['#value']   = "NA";
        $form['step_1']['body_type']['#value']    = "NA"; $form['step_1']['body_type']['#options']    = ["NA"=>t("-------------------N/A-------------------")];
        $form['step_1']['variant']['#value']      = "NA"; $form['step_1']['variant']['#options']      = ["NA"=>t("-------------------N/A-------------------")];
        $form_state->setRebuild();
        return $form['step_1']; // return $form['model_year'];
    }

    public function getBodyTypeIDs_AjaxCallback(array &$form, FormStateInterface $form_state){
        $options = $this -> getModelBodyTypeIDs($form_state->getValue('model_id'), $form_state->getValue('model_year'));
        $form['step_1']['body_type']['#options'] = $options;
        $form['step_1']['body_type']['#value']   = "NA";
        $form['step_1']['variant']['#value']     = "NA"; $form['step_1']['variant']['#options']     = ["NA"=>t("-------------------N/A-------------------")];
        $form_state->setRebuild();
        return $form['step_1']; // return $form['body_type'];
    }
    public function getVariants_AjaxCallback(array &$form, FormStateInterface $form_state){
        $options = $this -> getVariants($form_state->getValue('model_id'), $form_state->getValue('model_year'), $form_state->getValue('body_type'));
        $form['step_1']['variant']['#options'] = $options;
        $form['step_1']['variant']['#value']   = "NA";
        $form_state->setRebuild();
        return $form['step_1']; // return $form['variant'];
    }

    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================


    public function getCarDetails_AjaxCallback(array &$form, FormStateInterface $form_state){
        $image_html = $this -> getCarImageHTML($form_state->getValue('variant'));
        $price      = $this -> getCarPrice($form_state->getValue('variant'));
        $form['car_info']['image']['#markup'] = $image_html;
        $form['car_info']['price']['#value']  = $price;
        $form_state->set('price', $price);
        $form_state->setRebuild();
        return $form['car_info'];
    }

    public function getBreakdownBudgetedCosts_AjaxCallback(array &$form, FormStateInterface $form_state){

        $variant_id         = $form_state->getValue('variant');
        $approximate_price  = $this->getCarPrice($variant_id);
        $annual_salary      = $form_state->getValue('annual_salary');
        $pay_cycle_code     = $form_state->getValue('pay_cycle_code');
        $annual_kilometres  = $form_state->getValue('annual_kilometres');
        $state_registered   = $form_state->getValue('state_registered');
        $post_code          = $form_state->getValue('post_code');
        $lease_period       = $form_state->getValue('lease_period');

        $form['quote']['packaged_reduction_net_income_per_pay_cycle']["#title"]  = $pay_cycle_code." Cost:";
        $result             = $this -> getQuote($variant_id, $approximate_price, $annual_salary, $pay_cycle_code, $annual_kilometres, $state_registered, $lease_period);

        $form['quote']['total_lease_per_pay_cycle_gross']["#value"]              = '$' . number_format($result['total_lease_per_pay_cycle_gross']             , 2, '.', ',');
        $form['quote']['packaged_reduction_net_income_per_pay_cycle']["#value"]  = '$' . number_format($result['packaged_reduction_net_income_per_pay_cycle'] , 2, '.', ',');
        $form['quote']['packaged_advantage_per_year']["#value"]                  = '$' . number_format($result['packaged_advantage_per_year']                 , 2, '.', ',');
        $form['quote']['fin_per_pay_cycle_net']["#value"]                        = '$' . number_format($result['fin_per_pay_cycle_net']                       , 2, '.', ',');
        $form['quote']['maint_per_pay_cycle_net']["#value"]                      = '$' . number_format($result['maint_per_pay_cycle_net']                     , 2, '.', ',');
        $form['quote']['t_per_pay_cycle_net']["#value"]                          = '$' . number_format($result['t_per_pay_cycle_net']                         , 2, '.', ',');
        $form['quote']['reg_per_pay_cycle_net']["#value"]                        = '$' . number_format($result['reg_per_pay_cycle_net']                       , 2, '.', ',');
        $form['quote']['ins_per_pay_cycle_net']["#value"]                        = '$' . number_format($result['ins_per_pay_cycle_net']                       , 2, '.', ',');
        $form['quote']['f_per_pay_cycle_net']["#value"]                          = '$' . number_format($result['f_per_pay_cycle_net']                         , 2, '.', ',');
        $form['quote']['rsa_per_pay_cycle_net']["#value"]                        = '$' . number_format($result['rsa_per_pay_cycle_net']                       , 2, '.', ',');
        $form['quote']['mfee_per_pay_cycle_net']["#value"]                       = '$' . number_format($result['mfee_per_pay_cycle_net']                      , 2, '.', ',');
        $form['quote']['total_lease_per_pay_cycle_net']["#value"]                = '$' . number_format($result['total_lease_per_pay_cycle_net']               , 2, '.', ',');
        $form['quote']['total_lease_per_pay_cycle_gst']["#value"]                = '$' . number_format($result['total_lease_per_pay_cycle_gst']               , 2, '.', ',');
        $form['quote']['total_lease_per_pay_cycle_gross']["#value"]              = '$' . number_format($result['total_lease_per_pay_cycle_gross']             , 2, '.', ',');

        return $form['quote'];
    }






    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================



    /**
     * {@inheritdoc}
     */
    public function getFormId()
    {
        return 'leasing_form';
    }
    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state)
    {

        $form['step_1'] = array(
            '#type' => 'fieldset',
            '#prefix' => '<div id="car_information">',
            '#suffix' => '</div>',
            '#collapsible' => FALSE,
		    '#collapsed' => FALSE,
        );
        $form['step_1']['title_1']  =  array(
            '#markup'    => '<h3>Step-1: Select your car</h3>',
        );
        $form['step_1']['make_id']   =  array(
            '#type'     => 'select',
            '#title'    => t('Make'),
            '#required' => FALSE,
            "#default_value"    => "NA",
            '#DANGEROUS_SKIP_CHECK'=>true,
            '#options'  => $this->getMakes($this->getAccessToken()),
            '#disabled' => FALSE,
            '#prefix' => '<div id="make_wrapper">',
            '#suffix' => '</div>',
            // "#ajax"     => [
            //     'callback' => '::getModels_AjaxCallback',
            //     'event' => 'change',
            //     // 'wrapper' => 'models_wrapper',
            //     'wrapper' => 'car_information',
            //     'speed'  => "fast",
            //     'effect' => "none",
            //     'progress' => [
            //         'type' => 'throbber',
            //         'message' => $this->t('Please wait...'),
            //     ],
            // ]
        );
        $form['step_1']['model_id']  =  array(
            '#type'     => 'select',
            '#title'    => t('Model'),
            '#required' => FALSE,
            "#default_value"    => "NA",
            '#DANGEROUS_SKIP_CHECK'=>true,
            '#options'  => $this -> getModels($form_state->getValue('make_id')),
            '#disabled'  => FALSE,
            '#prefix' => '<div id="models_wrapper">',
            '#suffix' => '</div>',
            // "#ajax"     => [
            //     'callback' => '::getModelYear_AjaxCallback',
            //     'event' => 'change',
            //     //'wrapper' => 'model_year_wrapper',
            //     'wrapper' => 'car_information',
            //     'speed'  => "fast",
            //     'effect' => "none",
            //     'progress' => [
            //         'type' => 'throbber',
            //         'message' => $this->t('Please wait...'),
            //     ],
            // ],
            // '#states' => [
            //     'disabled' => [
            //         ':input[name="make_id"]' => ['value' => 'NA'],
            //     ]
            // ],
        );


        $form['step_1']['model_year']  =  array(
            '#type'     => 'select',
            '#title'    => t('Year'),
            '#required' => FALSE,
            "#default_value"    => "NA",
            '#DANGEROUS_SKIP_CHECK'=>true,
            '#options'  => $this -> getModelYears($form_state->getValue('model_id')),
            '#disabled'  => FALSE,
            '#prefix' => '<div id="model_year_wrapper">',
            '#suffix' => '</div>',
            // "#ajax"     => [
            //     'callback' => '::getBodyTypeIDs_AjaxCallback',
            //     'event' => 'change',
            //     //'wrapper' => 'body_type_wrapper',
            //     'wrapper' => 'car_information',
            //     'speed'  => "fast",
            //     'effect' => "none",
            //     'progress' => [
            //         'type' => 'throbber',
            //         'message' => $this->t('Please wait...'),
            //     ],
            // ],
            // '#states' => [
            //     'disabled' => [
            //         ':input[name="model_id"]' => ['value' => 'NA'],
            //     ]
            // ],
        );

        $form['step_1']['body_type']  =  array(
            '#type'     => 'select',
            '#title'    => t('Body Type'),
            '#required' => FALSE,
            "#default_value"    => "NA",
            '#DANGEROUS_SKIP_CHECK'=>true,
            '#options'  => $this -> getModelBodyTypeIDs($form_state->getValue('model_id'), $form_state->getValue('model_year')),
            '#disabled'  => FALSE,
            '#prefix' => '<div id="body_type_wrapper">',
            '#suffix' => '</div>',
            // "#ajax"     => [
            //     'callback' => '::getVariants_AjaxCallback',
            //     'event' => 'change',
            //     //'wrapper' => 'variant_wrapper',
            //     'wrapper' => 'car_information',
            //     'speed'  => "fast",
            //     'effect' => "none",
            //     'progress' => [
            //         'type' => 'throbber',
            //         'message' => $this->t('Please wait...'),
            //     ],
            // ],
            // '#states' => [
            //     'disabled' => [
            //         ':input[name="model_year"]' => ['value' => 'NA'],
            //     ]
            // ],
        );

        $form['step_1']['variant']  =  array(
            '#type'     => 'select',
            '#title'    => t('Variant'),
            '#required' => FALSE,
            "#default_value"    => "NA",
            '#DANGEROUS_SKIP_CHECK'=>true,
            '#options'  => $this -> getVariants($form_state->getValue('model_id'), $form_state->getValue('model_year'), $form_state->getValue('body_type')),
            '#disabled'  => FALSE,
            '#prefix' => '<div id="variant_wrapper">',
            '#suffix' => '</div>',
            // "#ajax"     => [
            //     'callback' => '::getCarDetails_AjaxCallback',
            //     'event' => 'change',
            //     'wrapper' => 'car_details_wrapper',
            //     'speed'  => "fast",
            //     'effect' => "none",
            //     'progress' => [
            //         'type' => 'throbber',
            //         'message' => $this->t('Please wait...'),
            //     ],
            // ],
            // '#states' => [
            //     'disabled' => [
            //         ':input[name="body_type"]' => ['value' => 'NA'],
            //     ]
            // ],
        );

        $form['car_info']  =  array(
            '#type' => 'fieldset',
            '#prefix' => '<div id="car_details_wrapper">',
            '#suffix' => '</div>',
            '#collapsible' => FALSE,
		    '#collapsed' => FALSE,
        );
        $form['car_info']['price']  =  array(
            '#type' => "textfield",
            '#value' => "NA",
            "#title" => "Price of Car (excl. on-road costs)",
            "#disabled" => TRUE,
        );
        $form['car_info']['image']  =  array(
            '#markup'    => '<img src="https://placehold.co/600x400"/>',
        );

        // ====================================================================================
        $form['information'] = array(
            '#type' => 'fieldset',
            '#prefix' => '<div id="personal_information">',
            '#suffix' => '</div>',
            '#collapsible' => FALSE,
		    '#collapsed' => FALSE,
        );
        $form['information']['title_1']              = array('#markup' => '<h3>Step-2: Your information</h3>',);
        $form['information']['annual_salary']        = array('#type'   => "textfield"     ,"#title" => "Annual Salary" );
        $form['information']['pay_cycle_code']       = array('#type'   => "select"        ,"#title" => "Pay Cycle"     ,"#options" => array("NA" => t("- Pay Cycle -"),"Weekly" => t("Weekly"),"Fortnightly" => t("Fortnightly"),"Bi-Monthly" => t("Bi-Monthly"),"Monthly" => t("Monthly")));
        $form['information']['annual_kilometres']    = array('#type'   => "textfield"     ,"#title" => "Annual KM"     );
        $form['information']['state_registered']     = array('#type'   => "select"        ,"#title" => "State"         ,"#options" => array("NA" => t("- State -"), "NSW" => t("NSW"), "VIC" => t("VIC"), "QLD" => t("QLD"), "ACT" => t("ACT"), "WA" => t("WA"), "SA" => t("SA"), "TAS" => t("TAS"), "NT" => t("NT")));
        $form['information']['post_code']            = array('#type'   => "textfield"     ,"#title" => "Postcode"      );
        $form['information']['lease_period']         = array('#type'   => "select"        ,"#title" => "Leasing Term"  ,"#options" => array("NA"=>t("- Leasing Term -"), "12"=>t("1 YR"), "24"=>t("2 YRs"), "36"=>t("3 YRs"), "48"=>t("4 YRs"), "60"=>t("5 YRs")));
        $form['information']['get_quote_button_new'] = array('#type' => 'textfield', "#disabled"=>FALSE, "#value"=>"Calculate Saving");
        // $form['information']['get_quote_button']   = array(
        //     '#type' => 'button',
        //     '#value' => t('Calculate Savings'),
        //     '#executes_submit_callback' => FALSE,
        //     // "#ajax"     => [
        //     //     'callback' => '::getBreakdownBudgetedCosts_AjaxCallback',
        //     //     'event' => 'mousedown',
        //     //     'wrapper' => 'quote_result',
        //     //     'speed'  => "fast",
        //     //     'effect' => "none",
        //     //     'progress' => [
        //     //         'type' => 'throbber',
        //     //         'message' => $this->t('Please wait...'),
        //     //     ],
        //     // ],
        // );




        // ====================================================================================
        $form['quote'] = array(
            '#type' => 'fieldset',
            '#prefix' => '<div id="quote_result">',
            '#suffix' => '</div>',
            '#collapsible' => FALSE,
		    '#collapsed' => FALSE,
        );
        $form['quote']['title_2']                                      = array('#markup' => '<h3>Breakdown: Budgeted Costs</h3>',);
        $form['quote']['packaged_reduction_net_income_per_pay_cycle']  = array('#type'   => "textfield"     ,"#title" => "Weekly Cost:"                 , "#disabled" => TRUE, "#prefix"=>"<div id='packaged_reduction_net_income_per_pay_cycle'>", "#suffix"=>"</div>"); //--- Weekly Cost
        $form['quote']['packaged_advantage_per_year']                  = array('#type'   => "textfield"     ,"#title" => "Estimated Annual Savings:"    , "#disabled" => TRUE, "#prefix"=>"<div id='packaged_advantage_per_year'>"                , "#suffix"=>"</div>"); //--- Estimated Annual Savings
        $form['quote']['fin_per_pay_cycle_net']                        = array('#type'   => "textfield"     ,"#title" => "Finance:"                     , "#disabled" => TRUE, "#prefix"=>"<div id='fin_per_pay_cycle_net'>"                      , "#suffix"=>"</div>"); //--- Finance
        $form['quote']['maint_per_pay_cycle_net']                      = array('#type'   => "textfield"     ,"#title" => "Service and Maintenance:"     , "#disabled" => TRUE, "#prefix"=>"<div id='maint_per_pay_cycle_net'>"                    , "#suffix"=>"</div>"); //--- Service and Maintenance
        $form['quote']['t_per_pay_cycle_net']                          = array('#type'   => "textfield"     ,"#title" => "Replacement Tyres:"           , "#disabled" => TRUE, "#prefix"=>"<div id='t_per_pay_cycle_net'>"                        , "#suffix"=>"</div>"); //--- Replacement Tyres
        $form['quote']['reg_per_pay_cycle_net']                        = array('#type'   => "textfield"     ,"#title" => "Registration and TP:"         , "#disabled" => TRUE, "#prefix"=>"<div id='reg_per_pay_cycle_net'>"                      , "#suffix"=>"</div>"); //--- Registration and TP
        $form['quote']['ins_per_pay_cycle_net']                        = array('#type'   => "textfield"     ,"#title" => "Comprehensive Insurance:"     , "#disabled" => TRUE, "#prefix"=>"<div id='ins_per_pay_cycle_net'>"                      , "#suffix"=>"</div>"); //--- Comprehensive Insurance
        $form['quote']['f_per_pay_cycle_net']                          = array('#type'   => "textfield"     ,"#title" => "Fuel:"                        , "#disabled" => TRUE, "#prefix"=>"<div id='f_per_pay_cycle_net'>"                        , "#suffix"=>"</div>"); //--- Fuel
        $form['quote']['rsa_per_pay_cycle_net']                        = array('#type'   => "textfield"     ,"#title" => "Roadside Assistance:"         , "#disabled" => TRUE, "#prefix"=>"<div id='rsa_per_pay_cycle_net'>"                      , "#suffix"=>"</div>"); //--- Roadside Assistance
        $form['quote']['mfee_per_pay_cycle_net']                       = array('#type'   => "textfield"     ,"#title" => "Management Fee:"              , "#disabled" => TRUE, "#prefix"=>"<div id='mfee_per_pay_cycle_net'>"                     , "#suffix"=>"</div>"); //--- Management Fee
        $form['quote']['total_lease_per_pay_cycle_net']                = array('#type'   => "textfield"     ,"#title" => "Total Lease Costs (ex. GST):" , "#disabled" => TRUE, "#prefix"=>"<div id='total_lease_per_pay_cycle_net'>"              , "#suffix"=>"</div>"); //--- Total Lease Costs (ex. GST)
        $form['quote']['total_lease_per_pay_cycle_gst']                = array('#type'   => "textfield"     ,"#title" => "GST:"                         , "#disabled" => TRUE, "#prefix"=>"<div id='total_lease_per_pay_cycle_gst'>"              , "#suffix"=>"</div>"); //--- GST
        $form['quote']['total_lease_per_pay_cycle_gross']              = array('#type'   => "textfield"     ,"#title" => "Total Lease Costs (inc. GST):", "#disabled" => TRUE, "#prefix"=>"<div id='total_lease_per_pay_cycle_gross'>"            , "#suffix"=>"</div>"); //--- Total Lease Costs (inc. G
        // ====================================================================================

        $form['#attached']['library'][] = 'leasing/leasing-library';
        return $form;
    }







    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    /**
     * {@inheritdoc}
     */
    public function validateForm(array &$form, FormStateInterface $form_state)
    {
        // if(strlen($form_state->getValue('phone')) < 10) {
        //   $form_state->setErrorByName('phone', $this->t('Please enter a valid Contact Number'));
        // }
    }
    /**
     * {@inheritdoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state)
    {
        // \Drupal::messenger()->addMessage(t(" Registration Done!! Registered Values are:"));
        // foreach ($form_state->getValues() as $key => $value) {
        //     \Drupal::messenger()->addMessage($key . ': ' . $value);
        // }
    }
}
