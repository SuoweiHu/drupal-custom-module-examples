function step1_reset_values(
    _reset_make_,
    _reset_models_,
    _reset_model_year_,
    _reset_body_type_,
    _reset_variant_,
    _reset_price_car_,
    _reset_image_car_,
){
    if(_reset_make_)        {$("#make_wrapper>div.form-item>select.form-select").val("NA");}
    if(_reset_models_)      {$("#models_wrapper>div.form-item>select.form-select").val("NA");     $("#models_wrapper>div.form-item>select.form-select").empty().append(`<option value="NA">-------------------N/A-------------------</option>`);}
    if(_reset_model_year_)  {$("#model_year_wrapper>div.form-item>select.form-select").val("NA"); $("#model_year_wrapper>div.form-item>select.form-select").empty().append(`<option value="NA">-------------------N/A-------------------</option>`);}
    if(_reset_body_type_)   {$("#body_type_wrapper>div.form-item>select.form-select").val("NA");  $("#body_type_wrapper>div.form-item>select.form-select").empty().append(`<option value="NA">-------------------N/A-------------------</option>`);}
    if(_reset_variant_)     {$("#variant_wrapper>div.form-item>select.form-select").val("NA");    $("#variant_wrapper>div.form-item>select.form-select").empty().append(`<option value="NA">-------------------N/A-------------------</option>`);}
    if(_reset_price_car_)   {$("#car_details_wrapper #edit-price").val("NA");}
    if(_reset_image_car_)   {$("#car_details_wrapper div.fieldset__wrapper img").attr("src", "https://placehold.co/600x400?text=600+x+400");}
}

// Listen-er for the make select
// (update options for the model select when make select is changed)
$("#make_wrapper>div.form-item>select.form-select").on("change", function() {
    const make_id = $("#make_wrapper>div.form-item>select.form-select").val();
    if(make_id != "NA"){
      var settings = {"url": "https://payme.catch-e.net.au/services/qq/vehicle_lookup/getModels?login=web_alliance&password=caRZT70Gv8pHs&make_id=" + String(make_id), "method": "GET", "timeout": 0,};
      $.ajax(settings).done(function (response) {
        var parser = new DOMParser();
        var xmlDoc = parser.parseFromString(response, "text/xml");
        var xmlElement = xmlDoc.getElementsByTagName("models")[0];
        var rowElements = xmlElement.children;
        var htmlOptions = "";
        htmlOptions += `<option value="NA">-------------------N/A-------------------</option>`;
        for (var i = 0; i < rowElements.length; i++) {
          var rowElement = rowElements[i];
          var modelId = rowElement.getElementsByTagName("model_id")[0].textContent;
          var name = rowElement.getElementsByTagName("name")[0].textContent;
          htmlOptions += `<option value="${modelId}">${name}</option>`;
          $("#models_wrapper>div.form-item>select.form-select").empty().append(htmlOptions);
          step1_reset_values(false, false, true, true, true, true, true);
        }
      });
    }
  });


// Listen-er for the model select
// (update options for the year select when model select is changed)
$("#models_wrapper>div.form-item>select.form-select").on("change", function() {
    const model_id = $("#models_wrapper>div.form-item>select.form-select").val();
    if(model_id != "NA"){
      var settings = {"url": "https://payme.catch-e.net.au/services/qq/vehicle_lookup/getModelYears/?login=web_alliance&password=caRZT70Gv8pHs&model_id=" + String(model_id), "method": "GET", "timeout": 0,};
      $.ajax(settings).done(function (response) {
        var parser = new DOMParser();
        var xmlDoc = parser.parseFromString(response, "text/xml");
        var xmlElement = xmlDoc.getElementsByTagName("model_years")[0];
        var rowElements = xmlElement.children;
        var htmlOptions = "";
        htmlOptions += `<option value="NA">-------------------N/A-------------------</option>`;
        for (var i = 0; i < rowElements.length; i++) {
          var rowElement = rowElements[i];
          var year = rowElement.getElementsByTagName("model_year")[0].textContent;
          htmlOptions += `<option value="${year}">${year}</option>`;
          $("#model_year_wrapper>div.form-item>select.form-select").empty().append(htmlOptions);
          step1_reset_values(false, false, false, true, true, true, true);
        }
      });
    }
  });

// Listen-er for the year select
// (update options for the body type select when year select is changed)
$("#model_year_wrapper>div.form-item>select.form-select").on("change", function() {
    const model_id   = $("#models_wrapper>div.form-item>select.form-select").val();
    const model_year = $("#model_year_wrapper>div.form-item>select.form-select").val();
    if(model_id != "NA" && model_year != "NA"){
      var settings = {"url": "https://payme.catch-e.net.au/services/qq/vehicle_lookup/getBodyTypes/?login=web_alliance&password=caRZT70Gv8pHs&model_id="+String(model_id)+"&model_year=" + String(model_year), "method": "GET", "timeout": 0,};
      $.ajax(settings).done(function (response) {
        var parser = new DOMParser();
        var xmlDoc = parser.parseFromString(response, "text/xml");
        var xmlElement = xmlDoc.getElementsByTagName("body_types")[0];
        var rowElements = xmlElement.children;
        var htmlOptions = "";
        htmlOptions += `<option value="NA">-------------------N/A-------------------</option>`;
        for (var i = 0; i < rowElements.length; i++) {
          var rowElement = rowElements[i];
          var body_type = rowElement.getElementsByTagName("body_type")[0].textContent;
          var body_type_id = rowElement.getElementsByTagName("body_type_id")[0].textContent;
          htmlOptions += `<option value="${body_type_id}">${body_type}</option>`;
          $("#body_type_wrapper>div.form-item>select.form-select").empty().append(htmlOptions);
          step1_reset_values(false, false, false, false, true, true, true);
        }
      });
    }
  });


// Listen-er for the body select
// (update options for the variant select when body select is changed)
$("#body_type_wrapper>div.form-item>select.form-select").on("change", function() {
    const model_id     = $("#models_wrapper>div.form-item>select.form-select").val();
    const model_year   = $("#model_year_wrapper>div.form-item>select.form-select").val();
    const body_type_id = $("#body_type_wrapper>div.form-item>select.form-select").val();
    if(model_id != "NA" && model_year != "NA" && body_type_id != "NA"){
      var settings = {"url": "https://payme.catch-e.net.au/services/qq/vehicle_lookup/getVariants/?login=web_alliance&password=caRZT70Gv8pHs&model_id="+String(model_id)+"&model_year="+String(model_year)+"&body_type_id="+String(body_type_id), "method": "GET", "timeout": 0,};
      $.ajax(settings).done(function (response) {
        var parser = new DOMParser();
        var xmlDoc = parser.parseFromString(response, "text/xml");
        var xmlElement = xmlDoc.getElementsByTagName("variants")[0];
        var rowElements = xmlElement.children;
        var htmlOptions = "";
        htmlOptions += `<option value="NA">-------------------N/A-------------------</option>`;
        for (var i = 0; i < rowElements.length; i++) {
          var rowElement = rowElements[i];
          var variant_description = rowElement.getElementsByTagName("description")[0].textContent;
          var variant_id = rowElement.getElementsByTagName("variant_id")[0].textContent;
          htmlOptions += `<option value="${variant_id}">${variant_description}</option>`;
          $("#variant_wrapper>div.form-item>select.form-select").empty().append(htmlOptions);
          step1_reset_values(false, false, false, false, false, true, true);
        }
      });
    }
  });



// Listen-er for the variant select
// (update car price and car image when variant select is changed)
$("#variant_wrapper>div.form-item>select.form-select").on("change", function() {
    const variant_id       = $("#variant_wrapper>div.form-item>select.form-select").val();
    if(variant_id != "NA"){
      var settings = {"url": "https://payme.catch-e.net.au/services/qq/vehicle_lookup/getVariant/?login=web_alliance&password=caRZT70Gv8pHs&variant_id="+String(variant_id), "method": "GET", "timeout": 0,};
      $.ajax(settings).done(function (response) {
        var parser = new DOMParser();
        var xmlDoc = parser.parseFromString(response, "text/xml");
        var variant = xmlDoc.getElementsByTagName("variant")[0];
        var list_price_gross = variant.getElementsByTagName("list_price_gross")[0].textContent;
        $("#car_details_wrapper #edit-price").val('$' + list_price_gross.toLocaleString());
      });
      var settings_ = {"url": "https://payme.catch-e.net.au/services/qq/vehicle_lookup/getVariantPhotos/?login=web_alliance&password=caRZT70Gv8pHs&variant_id="+String(variant_id), "method": "GET", "timeout": 0,};
      $.ajax(settings_).done(function (response) {
        var parser = new DOMParser();
        var xmlDoc = parser.parseFromString(response, "text/xml");
        var variant = xmlDoc.getElementsByTagName("variant")[0];
        var image_code = variant.getElementsByTagName("photo_code")[0].textContent;
        $("#car_details_wrapper div.fieldset__wrapper img").attr("src", "https://payme2.catch-e.net.au/core/services/Redbook/photos/AUS/"+String(image_code)+".jpg");
      });
    }
  });







var button_InputElement = document.getElementById('edit-get-quote-button-new');
button_InputElement.style = "appearance:button;-webkit-appearance: button; -moz-appearance: button;";
button_InputElement.type = "button";
$("#edit-get-quote-button-new").mousedown(function() {
    const variant_id         = $("#edit-variant").val();
    const approximate_price  = String($("#edit-price").val()).replace(/\$|,/g, "");
    const annual_salary      = $("#edit-annual-salary").val();
    const pay_cycle_code     = $("#edit-pay-cycle-code").val();
    const annual_kilometres  = $("#edit-annual-kilometres").val();
    const state_registered   = $("#edit-state-registered").val();
    const post_code          = $("#edit-post-code").val();
    const lease_period       = $("#edit-lease-period").val();
    $("#packaged_reduction_net_income_per_pay_cycle>div>label").val(pay_cycle_code + " " + "Cost");

    // console.log("variant_id          :", variant_id       );
    // console.log("approximate_price   :", approximate_price);
    // console.log("annual_salary       :", annual_salary    );
    // console.log("pay_cycle_code      :", pay_cycle_code   );
    // console.log("annual_kilometres   :", annual_kilometres);
    // console.log("state_registered    :", state_registered );
    // console.log("post_code           :", post_code        );
    // console.log("lease_period        :", lease_period     );

    if(variant_id        == "NA" || variant_id        == ""){alert(`"Variant Id"        is Empty`); return;}
    if(approximate_price == "NA" || approximate_price == ""){alert(`"Approximate Price" is Empty`); return;}
    if(annual_salary     == "NA" || annual_salary     == ""){alert(`"Annual Salary"     is Empty`); return;}
    if(pay_cycle_code    == "NA" || pay_cycle_code    == ""){alert(`"Pay Cycle_code"    is Empty`); return;}
    if(annual_kilometres == "NA" || annual_kilometres == ""){alert(`"Annual Kilometres" is Empty`); return;}
    if(state_registered  == "NA" || state_registered  == ""){alert(`"State Registered"  is Empty`); return;}
    if(post_code         == "NA" || post_code         == ""){alert(`"Post Code"         is Empty`); return;}
    if(lease_period      == "NA" || lease_period      == ""){alert(`"Lease Period"      is Empty`); return;}

    var settings = {"url": `https://payme.catch-e.net.au/services/qq/lease/getQuote/?login=web_alliance&password=caRZT70Gv8pHs&variant_id=${variant_id}&approximate_price=${approximate_price}&annual_salary=${annual_salary}&pay_cycle_code=${pay_cycle_code}&annual_kilometres=${annual_kilometres}&state_registered=${state_registered}&lease_period=${lease_period}`, "method": "GET", "timeout": 0,};
    $.ajax(settings).done(function (response) {
        var parser = new DOMParser();
        var xmlDoc = parser.parseFromString(response, "text/xml");
        var xmlElement = xmlDoc.getElementsByTagName("quote")[0];

        const packaged_reduction_net_income_per_pay_cycle  = xmlElement.getElementsByTagName("packaged_reduction_net_income_per_pay_cycle")[0].textContent;
        const packaged_advantage_per_year                  = xmlElement.getElementsByTagName("packaged_advantage_per_year"                )[0].textContent;
        const fin_per_pay_cycle_net                        = xmlElement.getElementsByTagName("fin_per_pay_cycle_net"                      )[0].textContent;
        const maint_per_pay_cycle_net                      = xmlElement.getElementsByTagName("maint_per_pay_cycle_net"                    )[0].textContent;
        const t_per_pay_cycle_net                          = xmlElement.getElementsByTagName("t_per_pay_cycle_net"                        )[0].textContent;
        const reg_per_pay_cycle_net                        = xmlElement.getElementsByTagName("reg_per_pay_cycle_net"                      )[0].textContent;
        const ins_per_pay_cycle_net                        = xmlElement.getElementsByTagName("ins_per_pay_cycle_net"                      )[0].textContent;
        const f_per_pay_cycle_net                          = xmlElement.getElementsByTagName("f_per_pay_cycle_net"                        )[0].textContent;
        const rsa_per_pay_cycle_net                        = xmlElement.getElementsByTagName("rsa_per_pay_cycle_net"                      )[0].textContent;
        const mfee_per_pay_cycle_net                       = xmlElement.getElementsByTagName("mfee_per_pay_cycle_net"                     )[0].textContent;
        const total_lease_per_pay_cycle_net                = xmlElement.getElementsByTagName("total_lease_per_pay_cycle_net"              )[0].textContent;
        const total_lease_per_pay_cycle_gst                = xmlElement.getElementsByTagName("total_lease_per_pay_cycle_gst"              )[0].textContent;
        const total_lease_per_pay_cycle_gross              = xmlElement.getElementsByTagName("total_lease_per_pay_cycle_gross"            )[0].textContent;

        // console.log("packaged_reduction_net_income_per_pay_cycle :", packaged_reduction_net_income_per_pay_cycle);
        // console.log("packaged_advantage_per_year                 :", packaged_advantage_per_year                );
        // console.log("fin_per_pay_cycle_net                       :", fin_per_pay_cycle_net                      );
        // console.log("maint_per_pay_cycle_net                     :", maint_per_pay_cycle_net                    );
        // console.log("t_per_pay_cycle_net                         :", t_per_pay_cycle_net                        );
        // console.log("reg_per_pay_cycle_net                       :", reg_per_pay_cycle_net                      );
        // console.log("ins_per_pay_cycle_net                       :", ins_per_pay_cycle_net                      );
        // console.log("f_per_pay_cycle_net                         :", f_per_pay_cycle_net                        );
        // console.log("rsa_per_pay_cycle_net                       :", rsa_per_pay_cycle_net                      );
        // console.log("mfee_per_pay_cycle_net                      :", mfee_per_pay_cycle_net                     );
        // console.log("total_lease_per_pay_cycle_net               :", total_lease_per_pay_cycle_net              );
        // console.log("total_lease_per_pay_cycle_gst               :", total_lease_per_pay_cycle_gst              );
        // console.log("total_lease_per_pay_cycle_gross             :", total_lease_per_pay_cycle_gross            );

        $("#packaged_reduction_net_income_per_pay_cycle>div.form-item>input") .val("$" + parseFloat(packaged_reduction_net_income_per_pay_cycle).toFixed(2).toLocaleString());
        $("#packaged_advantage_per_year>div.form-item>input")                 .val("$" + parseFloat(packaged_advantage_per_year)                .toFixed(2).toLocaleString());
        $("#fin_per_pay_cycle_net>div.form-item>input")                       .val("$" + parseFloat(fin_per_pay_cycle_net)                      .toFixed(2).toLocaleString());
        $("#maint_per_pay_cycle_net>div.form-item>input")                     .val("$" + parseFloat(maint_per_pay_cycle_net)                    .toFixed(2).toLocaleString());
        $("#t_per_pay_cycle_net>div.form-item>input")                         .val("$" + parseFloat(t_per_pay_cycle_net)                        .toFixed(2).toLocaleString());
        $("#reg_per_pay_cycle_net>div.form-item>input")                       .val("$" + parseFloat(reg_per_pay_cycle_net)                      .toFixed(2).toLocaleString());
        $("#ins_per_pay_cycle_net>div.form-item>input")                       .val("$" + parseFloat(ins_per_pay_cycle_net)                      .toFixed(2).toLocaleString());
        $("#f_per_pay_cycle_net>div.form-item>input")                         .val("$" + parseFloat(f_per_pay_cycle_net)                        .toFixed(2).toLocaleString());
        $("#rsa_per_pay_cycle_net>div.form-item>input")                       .val("$" + parseFloat(rsa_per_pay_cycle_net)                      .toFixed(2).toLocaleString());
        $("#mfee_per_pay_cycle_net>div.form-item>input")                      .val("$" + parseFloat(mfee_per_pay_cycle_net)                     .toFixed(2).toLocaleString());
        $("#total_lease_per_pay_cycle_net>div.form-item>input")               .val("$" + parseFloat(total_lease_per_pay_cycle_net)              .toFixed(2).toLocaleString());
        $("#total_lease_per_pay_cycle_gst>div.form-item>input")               .val("$" + parseFloat(total_lease_per_pay_cycle_gst)              .toFixed(2).toLocaleString());
        $("#total_lease_per_pay_cycle_gross>div.form-item>input")             .val("$" + parseFloat(total_lease_per_pay_cycle_gross)            .toFixed(2).toLocaleString());
    });

});
