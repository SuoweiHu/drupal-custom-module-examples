// Select the countdown component element
const countdownElement = document.getElementById('countdown');

// Set initial countdown value
let countdown = 3;

// Function to update countdown element
function updateCountdown() {
  countdownElement.textContent = countdown;

  if (countdown === 0) {
    // Redirect to Google when countdown reaches 0
    window.location.href = 'http://localhost:52330/utility-read-cookie.html';
  } else {
    countdown--;
    // Call the function recursively after 1 second
    setTimeout(updateCountdown, 1000);
  }
}

// Start the countdown
updateCountdown();