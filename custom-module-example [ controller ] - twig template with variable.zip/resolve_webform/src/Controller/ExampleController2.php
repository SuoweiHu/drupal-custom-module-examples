<?php

namespace Drupal\resolve_webform\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * An example controller.
 */
class ExampleController2 extends ControllerBase {

  /**
   * Returns a render-able array for a test page.
   */
  public function content($user_id) {
    // $build = [
    //   '#markup' => $this->t($user_id),
    // ];
    // return $build;
    return [
        '#theme' => 'hello_block',
        '#data' => ['age' => '31', 'DOB' => '2 May 2000'],
      ];
  }

}