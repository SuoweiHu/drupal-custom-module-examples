<?php

namespace Drupal\resolve_webform\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * An example controller.
 */
class ExampleController extends ControllerBase {

  /**
   * Returns a render-able array for a test page.
   */
  public function content() {
    $build = [
      '#markup' => $this->t('You have not logged in !<br> Will direct in <div style="display:inline; font-size: 20px;" id="countdown">X</div>'),
    ];
    $build['#attached']['library'][] = 'resolve_webform/redirect-javascript';
    return $build;
  }

}